# README

## LIST OF FOLDERS AND FILES

 * **`idlv-incremental`** folder contains all the necessary libraries and script to execute _I-DLV Incremental_
 
 * **`solver`** folder contains the binaries of `dlv2` and `clingo5.4`
 
 * **`test`** folder contains a simple example for testing _I-DLV Incremental_
   * `recursion/recursion.*.asp`: ASP files given in input to _I-DLV Incremental_.
   * `disjunction/disjunction.*.asp`: ASP files given in input to _I-DLV Incremental_.
   * `template.xml`: it is an XML file containing all the instructions that have to be executed by _I-DLV Incremental_.

## Example 1 - Disjunction

    <load path="test/disjunction/disjunction.0.asp"/>
    <load path="test/disjunction/disjunction.1.asp"/>
    <ground run_mode="updateonly"/>
    <load path="test/disjunction/disjunction.2.asp"/>
    <ground run_mode="updateonly"/>
    <load path="test/disjunction/disjunction.3.asp"/>
    <ground run_mode="updateonly"/>
    <load path="test/disjunction/disjunction.4.asp"/>
    <ground/>
    <reset/>
    <exit/>


## Example 2 - Recursion

    <load path="test/recursion/recursion.0.asp"/>
    <ground run_mode="updateonly"/>
    <load path="test/recursion/recursion.1.asp"/>
    <ground run_mode="updateonly"/>
    <load path="test/recursion/recursion.2.asp"/>
    <ground/>
    <reset/>
    <exit/>


## HOW TO EXECUTE

* The compressed file contains the directory "idlv-incremental/" which provides a standalone executable of _OI-DLV_. 

* There is no need to install any library.

* Just extract the compressed file to a known location on your computer, and from that location type 
  * `./idlv-incremental/i2dlv --isd < test/disjunction/template.xml | ./solver/dlv2 --mode=wasp --verbose=0` 
  * `./idlv-incremental/i2dlv --isd < test/recursion/template.xml | ./solver/clingo5.4 --mode=clasp --verbose=0` 
